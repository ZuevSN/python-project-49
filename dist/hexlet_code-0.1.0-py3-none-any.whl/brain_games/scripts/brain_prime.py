from brain_games.scripts import respondent
from brain_games.games import game_prime


def main():
    respondent.responde(game_prime)


if __name__ == "__main__":
    main()
