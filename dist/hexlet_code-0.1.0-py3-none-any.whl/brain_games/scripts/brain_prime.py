from brain_games.scripts.respondent import engine
from brain_games.games import game_prime


def main():
    engine(game_prime)


if __name__ == "__main__":
    main()
