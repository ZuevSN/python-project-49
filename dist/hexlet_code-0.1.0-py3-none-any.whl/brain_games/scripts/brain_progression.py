from brain_games.scripts import respondent
from brain_games.games import game_progression


def main():
    respondent.responde(game_progression)


if __name__ == "__main__":
    main()
