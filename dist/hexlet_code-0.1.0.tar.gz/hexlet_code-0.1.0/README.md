### Hexlet tests and linter status:
[![Actions Status](https://github.com/ZuevSN/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/ZuevSN/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/db219f5d644e805eb53c/maintainability)](https://codeclimate.com/github/ZuevSN/python-project-49/maintainability)

[![asciicast](https://asciinema.org/a/wbiCklrzUkPb4rGIMpUL0IOwU.svg)](https://asciinema.org/a/wbiCklrzUkPb4rGIMpUL0IOwU)