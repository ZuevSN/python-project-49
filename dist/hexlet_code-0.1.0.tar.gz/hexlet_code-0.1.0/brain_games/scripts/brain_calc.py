from brain_games.scripts import respondent
from brain_games.games import game_calc


def main():
    respondent.responde(game_calc)


if __name__ == "__main__":
    main()
