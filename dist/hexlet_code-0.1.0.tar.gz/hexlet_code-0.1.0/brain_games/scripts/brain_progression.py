from brain_games.scripts.respondent import engine
from brain_games.games import game_progression


def main():
    engine(game_progression)


if __name__ == "__main__":
    main()
